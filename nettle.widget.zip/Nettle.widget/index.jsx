import { App } from "./lib/App.jsx"
import { css } from "uebersicht"
export const refreshFrequency = 4000

export const command = (dispatch) => {}

export const initialState = { type: 'NOT_READY' };

const READY_STATE = {
  loading: false,
  ready: true,
  error: null,
}

export const updateState = (event, previousState) => {
  switch (event.type) {
    case 'NOT_READY':
      return { ...previousState, loading: true, ready: false }
    case 'READY':
      return { ...previousState, ...READY_STATE, ...event.data }
    case 'ERROR':
      return { ...previousState, ...READY_STATE, error: event.error }
    default:
      return previousState
  }
}
export const className = css({
  fontFamily: 'sans-serif',
  position: 'fixed',
  top: '0',
  left: '0',
})

export const render = (props, dispatch) => <App {...props} dispatch={dispatch} />
